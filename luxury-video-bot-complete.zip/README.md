# Luxury Video Bot 🚀

Et automatisk Node.js-system som:
- Lager AI-manus (GPT-4)
- Genererer voiceover (ElevenLabs)
- Henter luksusvideo (Pexels)
- Kombinerer alt og (senere) laster opp til YouTube Shorts

## Kjøring

1. Fyll ut `.env` med API-nøklene dine
2. Kjør `npm install`
3. Kjør `npm start`

## Filer
- `/tmp/voice.mp3`
- `/tmp/background.mp4`

Neste steg: Kombiner disse med CapCut API eller ffmpeg + last opp til YouTube.