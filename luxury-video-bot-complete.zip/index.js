require("dotenv").config();
const axios = require("axios");
const fs = require("fs");

async function main() {
  console.log("🎬 Starter produksjon...");

  const openAIResponse = await axios.post("https://api.openai.com/v1/chat/completions", {
    model: "gpt-4",
    messages: [
      { role: "system", content: "Du er en ekspert på luksus lifestyle content." },
      { role: "user", content: "Skriv et kraftfullt manus til en kort luksus-motivasjonsvideo (20 sekunder)." }
    ],
    temperature: 0.85
  }, {
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    }
  });

  const script = openAIResponse.data.choices[0].message.content.trim();
  console.log("✅ Manus:
", script);

  const voiceResp = await axios.post("https://api.elevenlabs.io/v1/text-to-speech/EXAVITQu4vr4xnSDxMaL", {
    text: script,
    model_id: "eleven_multilingual_v2",
    voice_settings: { stability: 0.4, similarity_boost: 0.7 }
  }, {
    headers: {
      "xi-api-key": process.env.ELEVENLABS_API_KEY,
      "Content-Type": "application/json"
    },
    responseType: "arraybuffer"
  });

  fs.writeFileSync("/tmp/voice.mp3", voiceResp.data);
  console.log("✅ Voiceover lagret!");

  const pexelsResp = await axios.get("https://api.pexels.com/videos/search", {
    headers: { Authorization: process.env.PEXELS_API_KEY },
    params: { query: "luxury lifestyle", orientation: "portrait", size: "medium", per_page: 1 }
  });

  const videoUrl = pexelsResp.data.videos[0].video_files.find(v => v.width === 1080).link;
  const videoFile = await axios.get(videoUrl, { responseType: "arraybuffer" });
  fs.writeFileSync("/tmp/background.mp4", videoFile.data);
  console.log("✅ Bakgrunnsvideo lagret!");

  console.log("📦 Filer klare: /tmp/voice.mp3 + /tmp/background.mp4");
  console.log("👉 Neste steg: Kombiner med CapCut API eller ffmpeg og last opp til YouTube.");
}

main().catch(err => {
  console.error("❌ FEIL:", err.response?.data || err.message);
});