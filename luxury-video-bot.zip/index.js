require('dotenv').config();
const axios = require('axios');

// Eksempel: Hent manus fra OpenAI
async function getScript() {
  const res = await axios.post("https://api.openai.com/v1/chat/completions", {
    model: "gpt-4",
    messages: [
      { role: "system", content: "Du er en ekspert på luksus og virale videomanus." },
      { role: "user", content: "Lag et manus til en luksus lifestyle video." }
    ],
    temperature: 0.9
  }, {
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    }
  });

  console.log("Manus:", res.data.choices[0].message.content);
}

getScript();